# Modelo de apresentação de projeto no GitHub

Use este roteiro para cada novo caso prático. Complete somente com informações verdadeiras e comprováveis.

## Problema
Qual tarefa manual, falha ou dificuldade existia? Em qual cenário de laboratório ou ambiente autorizado?

## Contexto
Tipo de dispositivo, cenário fictício ou real autorizado, volume de trabalho, limitações e critérios de sucesso.

## Solução aplicada
O que você fez? Por que essa abordagem era adequada? Quais ferramentas foram necessárias?

## Como reproduzir
Comandos, requisitos e passos seguros para testar sem compartilhar credenciais.

## Evidências
Capturas anonimizadas, logs sanitizados ou dados sintéticos **sempre claramente identificados**. Distinguir testes locais de execução real.

## Resultado e impacto
Exemplo de tabela a preencher com dados reais:

| Indicador | Antes | Depois | Como foi medido |
| --- | --- | --- | --- |
| Tempo de coleta | a medir | a medir | cronômetro |
| Passos manuais | a contar | a contar | procedimento |
| Equipamentos cobertos | a informar | a informar | inventário autorizado |

## Limitações e próximos passos
O que ainda não foi testado? Onde o método não funciona? Qual seria a evolução útil?
