# Roteiro de evolução — automação de infraestrutura

O objetivo é evoluir de tarefas pequenas para resultados comprováveis, sempre documentando: **problema -> solução -> evidência -> resultado**.

## Fase 1 — Coleta básica de interfaces

**Problema:** o analista consulta e copia manualmente a saída de interfaces.

**Entrega:** script por SSH para um equipamento e relatório de texto.

**Validação sugerida:** executar no laboratório, confirmar que o relatório corresponde à saída exibida no dispositivo e medir tempo manual x automatizado.

## Fase 2 — Coleta em múltiplos dispositivos

**Problema:** repetir a mesma coleta manualmente em vários switches ou roteadores.

**Entrega planejada:** leitura de inventário local controlado, execução em sequência e relatório consolidado. Tratar equipamentos inacessíveis sem interromper toda a rotina.

**Resultado a medir:** tempo de trabalho e taxa de sucesso da coleta.

## Fase 3 — Análise de incidentes comuns

**Problema:** identificar rapidamente interfaces inativas, falhas de link ou contadores de erro.

**Entrega planejada:** análise básica dos resultados para gerar indicadores e uma lista de atenção.

**Resultado a medir:** tempo de triagem e consistência do diagnóstico.

## Fase 4 — Monitoramento e observabilidade

**Problema:** acompanhar eventos e saúde da rede de forma proativa.

**Entrega planejada:** um caso prático de uso de Zabbix e/ou Grafana, com visualizações ou alertas; explicar a contribuição da automação na coleta e na análise.

**Resultado a medir:** exemplos de incidentes detectados e tempo de investigação, quando possível.

## Regras para todos os projetos

- Primeiro registrar o **problema**, só então escolher a tecnologia.
- Não afirmar ganho percentual ou redução de tempo sem medição.
- Usar laboratórios ou ambientes com autorização expressa.
- Antes de divulgar resultados, remover hostnames, IPs, seriais, credenciais e dados empresariais sensíveis.
- Manter os projetos pequenos, demonstráveis e explicados de forma simples.
