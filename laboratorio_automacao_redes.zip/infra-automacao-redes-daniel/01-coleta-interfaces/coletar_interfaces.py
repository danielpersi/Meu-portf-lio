"""Coleta informações de interfaces por SSH e salva um relatório local.

Projeto inicial de automação de redes: consulta apenas; não altera configurações.
Use exclusivamente em equipamentos próprios ou para os quais exista autorização.
"""

import argparse
import getpass
import os
import re
import sys
from datetime import datetime, timezone
from pathlib import Path

from netmiko import ConnectHandler
from netmiko.exceptions import NetmikoAuthenticationException, NetmikoTimeoutException


PASTA_SAIDAS = Path(__file__).resolve().parent / "saidas"


def nome_seguro(valor: str) -> str:
    """Normaliza um identificador para uso no nome de um arquivo."""
    return re.sub(r"[^a-zA-Z0-9_.-]", "_", valor)[:80]


def salvar_relatorio(host: str, tipo: str, comando: str, resposta: str) -> Path:
    """Registra o resultado da consulta em pasta ignorada pelo Git."""
    PASTA_SAIDAS.mkdir(parents=True, exist_ok=True)
    horario = datetime.now(timezone.utc)
    arquivo = PASTA_SAIDAS / f"interfaces_{nome_seguro(host)}_{horario:%Y%m%d_%H%M%S_%f}.txt"
    conteudo = (
        "RELATORIO DE CONSULTA DE INTERFACES\n"
        f"Data/hora (UTC): {horario:%Y-%m-%d %H:%M:%S}\n"
        f"Equipamento: {host}\n"
        f"Tipo Netmiko: {tipo}\n"
        f"Comando: {comando}\n"
        + "-" * 55 + "\n"
        + resposta.rstrip() + "\n"
    )
    arquivo.write_text(conteudo, encoding="utf-8")
    return arquivo


def obter_argumentos() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Executa um comando de consulta por SSH e salva a resposta localmente."
    )
    parser.add_argument("--host", required=True, help="IP ou hostname do equipamento autorizado")
    parser.add_argument("--tipo", default="cisco_ios", help="device_type do Netmiko (padrão: cisco_ios)")
    parser.add_argument("--usuario", default=os.getenv("NET_USERNAME"), help="Usuário SSH; também aceita NET_USERNAME")
    parser.add_argument("--comando", default="show interfaces", help="Comando de consulta compatível com o equipamento")
    parser.add_argument("--porta", default=22, type=int, help="Porta SSH (padrão: 22)")
    return parser.parse_args()


def main() -> int:
    args = obter_argumentos()
    usuario = args.usuario or input("Usuário SSH: ").strip()
    senha = os.getenv("NET_PASSWORD") or getpass.getpass("Senha SSH: ")
    if not usuario or not senha:
        print("Erro: usuário e senha são obrigatórios.", file=sys.stderr)
        return 2

    dispositivo = {
        "device_type": args.tipo,
        "host": args.host,
        "username": usuario,
        "password": senha,
        "port": args.porta,
        "conn_timeout": 15,
        "auth_timeout": 20,
    }
    conexao = None
    try:
        print(f"Conectando ao dispositivo {args.host}...")
        conexao = ConnectHandler(**dispositivo)
        resposta = conexao.send_command(args.comando, read_timeout=60)
        caminho = salvar_relatorio(args.host, args.tipo, args.comando, resposta)
        print(f"Consulta concluída. Relatório local salvo em: {caminho}")
        print("Antes de compartilhar, revise e anonimize qualquer informação sensível.")
        return 0
    except (NetmikoTimeoutException, NetmikoAuthenticationException) as erro:
        print(f"Falha de SSH/autenticação: {erro}", file=sys.stderr)
        return 1
    except (OSError, ValueError) as erro:
        print(f"Erro de conexão, comando ou arquivo: {erro}", file=sys.stderr)
        return 1
    finally:
        if conexao is not None:
            conexao.disconnect()


if __name__ == "__main__":
    raise SystemExit(main())
