# Projeto 01 — Coleta de interfaces de rede via SSH

## 1. Problema

Consultar interfaces manualmente em um equipamento exige acesso, execução de comandos e cópia de resultados. Em rotinas repetitivas, isso pode consumir tempo e dificultar a padronização das evidências técnicas.

## 2. Solução proposta

Criar um script curto em Python usando **Netmiko** para:

1. Conectar por SSH a um equipamento **autorizado**;
2. Executar `show interfaces` (ou outro comando de consulta configurado pelo usuário);
3. Salvar a resposta em um arquivo `.txt` local, com horário, equipamento e comando.

O script **não modifica a configuração de rede**.

## 3. Como testar

Siga as instruções de instalação no [README principal](../README.md).

Exemplo para dispositivo Cisco IOS, substituindo os dados pelo seu ambiente autorizado:

```bash
python 01-coleta-interfaces/coletar_interfaces.py --host IP_AUTORIZADO --tipo cisco_ios --usuario SEU_USUARIO --comando "show interfaces"
```

É possível testar outros tipos suportados pelo Netmiko, como `ubiquiti_edgerouter`, `ubiquiti_edgeswitch` ou `ubiquiti_unifiswitch`. **O comando não é universal**: consulte a CLI correspondente ao equipamento e à versão de firmware.

Em caso de erro de autenticação, timeout ou indisponibilidade de SSH, confira as permissões, conectividade e configuração do equipamento de laboratório. Não exponha a senha em linhas de comando.

## 4. Evidência disponível

O arquivo [exemplo-saida-ficticia.txt](exemplo-saida-ficticia.txt) é **apenas ilustrativo** e não prova execução em um dispositivo real. Os relatórios reais são salvos em `saidas/`, pasta ignorada pelo Git para evitar divulgação acidental de informações internas.

## 5. Resultado

**Status atual:** implementação inicial; **teste de rede real ainda não documentado**.

Ao testar, preencher com evidências verificadas:

- Tempo de execução manual: **a medir**;
- Tempo com script: **a medir**;
- Quantidade de equipamentos consultados: **a informar**;
- Problema evitado ou ganho operacional: **a descrever após o teste**.

## 6. Próximas melhorias

- Coletar dados de uma lista de equipamentos autorizados;
- Validar erros de interface e destacar portas inativas;
- Consolidar resultados em CSV, preservando a confidencialidade;
- Explorar integração com monitoramento Zabbix/Grafana.
