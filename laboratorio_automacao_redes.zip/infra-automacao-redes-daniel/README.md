# Automação de Redes e Infraestrutura

**Portfólio de projetos práticos de um analista de redes.**

O foco deste repositório não é demonstrar código complexo. É documentar **problemas de infraestrutura, a solução aplicada e o resultado observado**, utilizando automação quando ela agrega valor ao trabalho técnico.

## Objetivo

Mostrar minha evolução na automação de tarefas de redes e infraestrutura: da coleta de informações via SSH até diagnósticos, relatórios e integrações com plataformas de monitoramento.

## Projetos

| Projeto | Problema que aborda | Entrega | Situação |
| --- | --- | --- | --- |
| [01 · Coleta de interfaces via SSH](01-coleta-interfaces/README.md) | Coleta manual e repetitiva de informações de interfaces | Script Python/Netmiko que consulta um equipamento e salva um relatório local | **Código inicial pronto; validação em laboratório pendente** |

> Resultados reais, testes e métricas serão adicionados à medida que os projetos forem validados. Um exemplo fictício não equivale a teste em equipamento real.

## Minha abordagem

1. **Problema** — identificar a tarefa manual, incidente ou ponto de atenção.
2. **Ação** — escolher a automação mais simples que resolva o problema.
3. **Evidência** — documentar o procedimento e compartilhar somente saídas sanitizadas.
4. **Resultado** — registrar o que melhorou, com métricas reais sempre que possível.
5. **Evolução** — ampliar a solução gradualmente, sem complicar o necessário.

## Competências abordadas

- Redes de computadores e troubleshooting
- SSH e coleta de informações de equipamentos
- Python aplicado à infraestrutura e à automação
- Netmiko para interação com CLIs de equipamentos de rede
- Documentação técnica e tratamento de falhas
- Monitoramento e observabilidade (futuros exemplos com Zabbix/Grafana)

## Primeiro projeto: como executar

Requisitos: Python 3.10+; equipamento **próprio ou autorizado**, acessível via SSH; credenciais válidas e comando compatível com o fabricante/modelo.

```bash
python -m venv .venv
```

No Windows PowerShell, ative o ambiente:

```powershell
.venv\Scripts\Activate.ps1
```

No macOS/Linux:

```bash
source .venv/bin/activate
```

Instale a dependência:

```bash
python -m pip install -r requirements.txt
```

Execute, substituindo `IP_AUTORIZADO` pelo IP real de um equipamento de laboratório ou ambiente autorizado:

```bash
python 01-coleta-interfaces/coletar_interfaces.py --host IP_AUTORIZADO --tipo cisco_ios --usuario SEU_USUARIO
```

A senha será solicitada sem aparecer na tela. O comando padrão é `show interfaces`. Para outro comando de consulta, use `--comando`, por exemplo `--comando "show ip interface brief"` em Cisco IOS. Consulte as particularidades da plataforma antes de executar.

As saídas reais são salvas na pasta local `01-coleta-interfaces/saidas/`, **não versionada no Git**.

## Próximas etapas

Veja [roteiro de evolução](docs/roteiro-de-evolucao.md) e o [modelo de documentação de resultados](docs/modelo-de-projeto.md).

## Segurança e transparência

- Nunca publique senhas, tokens, chaves SSH ou arquivos com credenciais.
- Não publique endereços IP internos, hostnames, topologias ou detalhes confidenciais de clientes/empresas sem autorização explícita.
- Os exemplos do repositório usam dados fictícios, identificados como tal.
- A execução do script é somente para consulta. Nenhuma alteração de configuração é realizada por ele.
- O projeto precisa ser testado em laboratório antes de qualquer uso operacional.

---

**Princípio do portfólio:** menos código por aparência; mais documentação de problemas resolvidos e resultados verificáveis.
